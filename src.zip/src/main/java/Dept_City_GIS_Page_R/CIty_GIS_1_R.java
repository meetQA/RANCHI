package Dept_City_GIS_Page_R;

public class CIty_GIS_1_R {
	public static final String btn_Analytics = "//a[@title=\"Analytics\"]";
	public static final String btn_Advance_Search = "//a[@title=\"Advance Search\"]";
	public static final String btn_Bookmark_Queries = "//a[@title=\"Bookmark Queries\"]";
	public static final String btn_Predefined_Queries = "//a[@title=\"Predefined Queries\"]";
	public static final String txt_Adance_Query = "//textarea[@placeholder=\"Values\"]";
	public static final String btn_Apply = "//button[text()=\"Apply\"]";
	public static final String btn_Unblink = "//button[text()=\"Unblink\"]";
	public static final String btn_Back = "//button[text()=\" Back\"]";
	public static final String btn_Clear = "//button[@id=\"btnquerybuilderclear\"]";
	public static final String btn_Save = "//div[@aria-labelledby=\"tabsearch\"]/div/button[text()=\"Save\"]";
	public static final String txt_Name = "//input[@placeholder=\"Name\"]";
	public static final String txt_Description = "//input[@placeholder=\"Description\"]";
	public static final String chk_qbispredefined = "//input[@id=\"chkqbispredefined\"]";
	public static final String btn_Save_Query = "//form[@id=\"frmadvancequerysave\"]//div/button[text()=\"Save\"]";
	public static final String btn_Verify = "//button[text()=\"Verify\"]";
	public static final String btn_Load_Query = "//button[text()=\"Load  Query\"]";
	public static final String btn_Load = "//button[text()=\"Load\"]";
	public static final String btn_Collapse_LQ = "//div[@aria-describedby=\"modalLoadQuery\"]/div/button[text()=\"collapse\"]";
	public static final String btn_Expand_LQ = "//div[@aria-describedby=\"modalLoadQuery\"]/div/button[text()=\"restore\"]";
	public static final String btn_Close_LQ = "//div[@aria-describedby=\"modalLoadQuery\"]/div/button[text()=\"Close\"]";
	public static final String btn_Spatial_Filter = "//button[text()=\"Spatial Filter\"]";
	public static final String txt_Values = "//input[@class=\"select2-search__field\"]";
	public static final String txt_Buffer = "//input[@placeholder=\"Enter Buffer Value\"]";
	public static final String btn_Ok = "//button[text()=\"Ok\"]";
	public static final String btn_Reset = "//form[@id=\"frmspatialfilter\"]//button[text()=\"Reset\"]";
	public static final String btn_Map_Extent = "//a[text()=\"Map Extent\"]";
	public static final String btn_Select_From_Map = "//a[text()=\"Select From Map\"]";

}
