package Application_Pages_R;

public class About_DSCL_R {
	public static String lnk_Read_More = "//a[text()=\"Read More\"]";
	

}
