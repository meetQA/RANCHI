package Application_Pages_R;

public class Sign_Up_Page_R {
	public static String btn_Sign_Up = "//a[@id=\"goRegister\"]";
	public static String Label_Register = "//h2[text()=\"Create your account\"]";
	public static String txt_First_Name = "//input[@placeholder=\"First Name\"]";
	public static String txt_Last_Name = "//input[@placeholder=\"Last Name\"]";
	public static String txt_User_Name = "//input[@placeholder=\"User Name\"]";
	public static String txt_Mobile_No = "//input[@placeholder=\"Mobile No.\"]";
	public static String txt_Email = "//input[@placeholder=\"Email\"]";
	public static String txt_captcha = "//input[@placeholder=\"Captcha\"]";
	public static String chk_Term_Con = "//input[@name=\"UserAgreement\" and @type=\"checkbox\"]";
	public static String btn_Sign_Up_2 = "//button[text()=\"Sign Up \"]";
	public static String Label_Success_Register = "//p[text()=\"User has been register successfully and password sent through e-mail.\"]";
	public static String lnk_Sign_In = "//a[@id=\"gosign\"]";
	public static String lnk_Term_Cond = "//a[text()=\"Terms and Conditions\"]";
	public static String Label_Term_Cond = "//h2[text()=\"Terms and Conditions\"]";
	public static String validation_message = "//p[text()=\"Something Wrong\"]";
	public static String validation_captcha = "//span[text()=\"Please Enter valid Captcha Code.\"]";

}
