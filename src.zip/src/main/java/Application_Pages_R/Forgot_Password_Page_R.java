package Application_Pages_R;

public class Forgot_Password_Page_R {
	public static String lnk_Forgot_Password = "//div[@class=\"col-sm-8 forgot-pass\"]/a";
	public static String Label_Forgot_Password = "//h3[text()=\"Forgot Username / Password\"]";
	public static String txt_Email = "//form[@action=\"/GIS/Account/UserForgetPassword\"]/div/div/input";
	public static String btn_Submit = "//button[text()=\"Submit \"]";
	public static String success_message = "//h2[text()=\"Success!\"]";
	public static String validation_message = "//span[text()=\"Please Enter valid Captcha Code.\"]";

}
