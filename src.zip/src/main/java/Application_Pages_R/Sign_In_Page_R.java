package Application_Pages_R;

public class Sign_In_Page_R {
	public static String txt_Login_Name = "//input[@data-val-required=\"Please Enter Valid Username\"]";
	public static String txt_Password = "//input[@data-val-required=\"Please Enter valid Password\"]";
	public static String btn_Sign_In = "//button[text()=\"Sign in \"]";
	public static String btn_Hide_View_Password = "//span[@class=\"input-group-text password input-group-icon input-group-addon-inverse\"]/i";
	public static String txt_loginUserName_error = "//span[text()=\"Please Enter Valid Username\"]";
	public static String txt_password_error = "//span[text()=\"Please Enter Valid Password\"]";
	public static String txt_error = "//span1[text()=\"Invalid User Name or Password.\"]";
	public static String btn_Close = "//div[@class=\"close-aside-btn\"]";
}
