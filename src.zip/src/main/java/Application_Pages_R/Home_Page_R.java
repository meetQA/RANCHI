package Application_Pages_R;

public class Home_Page_R {
	public static String URL = "https://sc1dehradun.sgligis.com//";
	public static String img_1 = "//div[@class=\"swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active\"]";
	public static String img_2 = "//div[@class=\"swiper-wrapper\"]/div[2]/div[@data-background=\"/Content/assets/images/gallery/4.jpg\"]";
	public static String img_3 = "//div[@class=\"swiper-wrapper\"]/div[3]/div[@data-background=\"/Content/assets/images/gallery/5.jpg\"]";
	public static String btn_Next_Slider = "//div[@class=\"next-btn\"]";
	public static String btn_Previous_Slider = "//div[@class=\"prev-btn\"]";
	public static String lnk_About_DSCL = "//a[text()=\"About DSCL\"]";
	public static String label_About_DSCL = "//strong[text()=\"About Dehradun Smart City \"]";
	public static String lnk_Sign_In = "//a[text()=\"Sign In\"]";
	public static String label_Sign_In = "//h3[text()=\"Member Login\"]";
	public static String btn_City_GIS = "//button[text()=\"City GIS\"]";
}
